"""toy_np.py: numpy-only loader, forward pass and batched greedy runner for the toy (Qwen2 format, safetensors).

PUBLIC FILE. It ships in toy_public.zip (BATTLE_LADDER design §2.2) so a sandbox without torch, transformers or
safetensors can run the toy. Needs only numpy and toy_tasks.py (same folder). Reads the safetensors format itself
(8-byte little-endian header length, JSON header, raw little-endian bytes); F32, F16 and BF16 tensors load as fp32.

The forward pass mirrors transformers' Qwen2ForCausalLM (eager attention) in fp32: token embedding; per layer
RMSNorm -> q/k/v projections (with bias) -> rotary embedding (rotate-half form) -> causal softmax attention ->
o_proj (no bias) -> residual; RMSNorm -> down(silu(gate(x)) * up(x)) -> residual; final RMSNorm; lm_head (the
embedding matrix when tie_word_embeddings is true). Its greedy outputs must equal the torch runner's on every dev
item (tested in tests/test_battle_toy.py and checked in E-TEST by build_toy.py parity).

CLI:
  python toy_np.py <model_dir> [--items dev_items.jsonl] [--delta delta.safetensors]
     prints "TOOL OK" and the per-skill exact-match scores. <model_dir> holds model.safetensors and config.json.
"""
from __future__ import annotations

import argparse
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import toy_tasks as tt  # noqa: E402

_DT = {"F32": ("<f4", 4), "F16": ("<f2", 2), "BF16": ("<u2", 2), "F64": ("<f8", 8), "I64": ("<i8", 8),
       "I32": ("<i4", 4)}
HEADER_LIMIT = 100 * 1024 * 1024


# --------------------------------------------------------------------------------------------- safetensors io
def read_header(path: str) -> tuple[dict, int]:
    with open(path, "rb") as fh:
        raw = fh.read(8)
        if len(raw) != 8:
            raise ValueError("file too short")
        (n,) = struct.unpack("<Q", raw)
        if n > HEADER_LIMIT:
            raise ValueError("header too large")
        header = json.loads(fh.read(n).decode("utf-8"))
    return header, 8 + n


def load_safetensors(path: str) -> dict:
    """{name: np.ndarray fp32} (other dtypes as stored). Checks offsets are in bounds and do not overlap."""
    header, base = read_header(path)
    size = os.path.getsize(path)
    out, spans = {}, []
    with open(path, "rb") as fh:
        for name, meta in header.items():
            if name == "__metadata__":
                continue
            dt = meta["dtype"]
            if dt not in _DT:
                raise ValueError(f"unknown dtype {dt}")
            np_dt, width = _DT[dt]
            a, b = meta["data_offsets"]
            shape = tuple(meta["shape"])
            count = int(np.prod(shape)) if shape else 1
            if not (0 <= a <= b and base + b <= size and b - a == count * width):
                raise ValueError(f"bad offsets for {name}")
            spans.append((a, b, name))
            fh.seek(base + a)
            arr = np.frombuffer(fh.read(b - a), dtype=np_dt).reshape(shape)
            if dt == "BF16":
                arr = (arr.astype(np.uint32) << 16).view(np.float32)
            elif dt == "F16":
                arr = arr.astype(np.float32)
            out[name] = np.array(arr)  # own, writable copy
    spans.sort()
    for (a1, b1, n1), (a2, b2, n2) in zip(spans, spans[1:]):
        if a2 < b1:
            raise ValueError(f"overlapping tensors {n1} {n2}")
    return out


def save_safetensors(path: str, tensors: dict, metadata: dict | None = None) -> None:
    """Write fp32 tensors (sorted by name, deterministic bytes). Same layout the safetensors library writes."""
    names = sorted(tensors)
    header, blobs, off = {}, [], 0
    for n in names:
        a = np.ascontiguousarray(tensors[n], dtype="<f4")
        blob = a.tobytes()
        header[n] = {"dtype": "F32", "shape": list(a.shape), "data_offsets": [off, off + len(blob)]}
        blobs.append(blob)
        off += len(blob)
    if metadata:
        header["__metadata__"] = {str(k): str(v) for k, v in metadata.items()}
    hb = json.dumps(header, separators=(",", ":")).encode("utf-8")
    hb += b" " * ((8 - len(hb) % 8) % 8)
    with open(path, "wb") as fh:
        fh.write(struct.pack("<Q", len(hb)))
        fh.write(hb)
        for blob in blobs:
            fh.write(blob)


# --------------------------------------------------------------------------------------------- model
class ToyModel:
    def __init__(self, weights: dict, config: dict):
        self.w = {k: np.asarray(v, dtype=np.float32) for k, v in weights.items()}
        self.cfg = config
        self.L = int(config["num_hidden_layers"])
        self.H = int(config["num_attention_heads"])
        self.KV = int(config["num_key_value_heads"])
        self.D = int(config["hidden_size"])
        self.hd = self.D // self.H
        self.eps = np.float32(config["rms_norm_eps"])
        theta = float(config.get("rope_theta", 10000.0))
        self.max_pos = int(config["max_position_embeddings"])
        inv = 1.0 / (theta ** (np.arange(0, self.hd, 2, dtype=np.int64).astype(np.float32) / self.hd))
        inv = inv.astype(np.float32)
        pos = np.arange(self.max_pos, dtype=np.float32)
        freqs = np.outer(pos, inv).astype(np.float32)
        emb = np.concatenate([freqs, freqs], axis=-1)
        self.cos = np.cos(emb).astype(np.float32)
        self.sin = np.sin(emb).astype(np.float32)
        self.embed = self.w["model.embed_tokens.weight"]
        if config.get("tie_word_embeddings", False) or "lm_head.weight" not in self.w:
            self.lm_head = self.embed
        else:
            self.lm_head = self.w["lm_head.weight"]

    @classmethod
    def load(cls, model_dir: str, delta_path: str | None = None) -> "ToyModel":
        with open(os.path.join(model_dir, "config.json"), "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        w = load_safetensors(os.path.join(model_dir, "model.safetensors"))
        if delta_path:
            d = load_safetensors(delta_path)
            for k, v in d.items():
                if k not in w or w[k].shape != v.shape:
                    raise ValueError(f"delta tensor {k} not in model or wrong shape")
                w[k] = (w[k].astype(np.float32) + v.astype(np.float32)).astype(np.float32)
        return cls(w, cfg)

    def _rms(self, x, weight):
        var = np.mean(x * x, axis=-1, keepdims=True, dtype=np.float32)
        return (weight * (x / np.sqrt(var + self.eps))).astype(np.float32)

    def _rope(self, x, pos):  # x: (B, heads, T, hd); pos: (T,)
        c = self.cos[pos][None, None]
        s = self.sin[pos][None, None]
        h = self.hd // 2
        rot = np.concatenate([-x[..., h:], x[..., :h]], axis=-1)
        return (x * c + rot * s).astype(np.float32)

    def forward(self, ids: np.ndarray, cache: list | None = None, start: int = 0):
        """ids: (B, T) int. Returns (logits (B, T, V) fp32, cache). cache holds per-layer (k, v) for positions < start."""
        B, T = ids.shape
        x = self.embed[ids].astype(np.float32)
        pos = np.arange(start, start + T)
        if cache is None:
            cache = [None] * self.L
        new_cache = []
        rep = self.H // self.KV
        scale = np.float32(1.0 / np.sqrt(self.hd))
        for li in range(self.L):
            p = f"model.layers.{li}."
            h = self._rms(x, self.w[p + "input_layernorm.weight"])
            q = h @ self.w[p + "self_attn.q_proj.weight"].T + self.w[p + "self_attn.q_proj.bias"]
            k = h @ self.w[p + "self_attn.k_proj.weight"].T + self.w[p + "self_attn.k_proj.bias"]
            v = h @ self.w[p + "self_attn.v_proj.weight"].T + self.w[p + "self_attn.v_proj.bias"]
            q = q.reshape(B, T, self.H, self.hd).transpose(0, 2, 1, 3)
            k = k.reshape(B, T, self.KV, self.hd).transpose(0, 2, 1, 3)
            v = v.reshape(B, T, self.KV, self.hd).transpose(0, 2, 1, 3)
            q = self._rope(q, pos)
            k = self._rope(k, pos)
            if cache[li] is not None:
                k = np.concatenate([cache[li][0], k], axis=2)
                v = np.concatenate([cache[li][1], v], axis=2)
            new_cache.append((k, v))
            if rep > 1:
                k = np.repeat(k, rep, axis=1)
                v = np.repeat(v, rep, axis=1)
            S = k.shape[2]
            att = (q @ k.transpose(0, 1, 3, 2)) * scale  # (B, H, T, S)
            qpos = pos[:, None]
            kpos = np.arange(S)[None, :]
            att = np.where(kpos <= qpos, att, np.float32(-np.inf))
            att = att - att.max(axis=-1, keepdims=True)
            att = np.exp(att)
            att = (att / att.sum(axis=-1, keepdims=True)).astype(np.float32)
            o = (att @ v).transpose(0, 2, 1, 3).reshape(B, T, self.D)
            x = (x + o @ self.w[p + "self_attn.o_proj.weight"].T).astype(np.float32)
            h = self._rms(x, self.w[p + "post_attention_layernorm.weight"])
            g = h @ self.w[p + "mlp.gate_proj.weight"].T
            u = h @ self.w[p + "mlp.up_proj.weight"].T
            act = (g / (1.0 + np.exp(-g))).astype(np.float32) * u
            x = (x + act @ self.w[p + "mlp.down_proj.weight"].T).astype(np.float32)
        x = self._rms(x, self.w["model.norm.weight"])
        logits = (x @ self.lm_head.T).astype(np.float32)
        return logits, new_cache

    def next_logits(self, ids: list[int]) -> np.ndarray:
        """Logits for the next token after `ids` (no cache; for checks)."""
        logits, _ = self.forward(np.asarray([ids], dtype=np.int64))
        return logits[0, -1]

    def greedy(self, prompts: list[list[int]], cap: int = tt.CAP, batch: int = 512) -> list[list[int]]:
        """Batched greedy decode with a KV cache. Prompts are grouped by length (no padding needed).

        Each output stops after its first <eos> or after `cap` tokens.
        """
        outs: list[list[int] | None] = [None] * len(prompts)
        by_len: dict[int, list[int]] = {}
        for i, p in enumerate(prompts):
            by_len.setdefault(len(p), []).append(i)
        for plen in sorted(by_len):
            idx_all = by_len[plen]
            for s in range(0, len(idx_all), batch):
                idx = idx_all[s:s + batch]
                ids = np.asarray([prompts[i] for i in idx], dtype=np.int64)
                if plen + cap > self.max_pos:
                    raise ValueError("prompt + cap longer than max_position_embeddings")
                logits, cache = self.forward(ids, None, 0)
                gen = np.zeros((len(idx), cap), dtype=np.int64)
                done = np.zeros(len(idx), dtype=bool)
                steps = 0
                for t in range(cap):
                    nxt = np.argmax(logits[:, -1, :], axis=-1)
                    gen[:, t] = nxt
                    steps = t + 1
                    done |= nxt == tt.EOS_ID
                    if done.all() or t == cap - 1:
                        break
                    logits, cache = self.forward(nxt[:, None], cache, plen + t)
                for r, i in enumerate(idx):
                    row = gen[r, :steps].tolist()
                    if tt.EOS_ID in row:
                        row = row[: row.index(tt.EOS_ID) + 1]
                    outs[i] = row
        return outs  # type: ignore[return-value]


def run_items(model: ToyModel, items: list[dict], cap: int = tt.CAP) -> list[list[str]]:
    """Greedy outputs (token strings) for items."""
    prompts = [tt.encode(it["prompt"]) for it in items]
    return [tt.decode(o) for o in model.greedy(prompts, cap)]


def evaluate(model: ToyModel, items: list[dict]) -> dict:
    return tt.score(items, run_items(model, items))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(allow_abbrev=False, description="numpy runner for the toy")
    ap.add_argument("model_dir")
    ap.add_argument("--items", help="JSONL items (default: regenerate the public dev set)")
    ap.add_argument("--delta", help="optional fp32 delta safetensors added to the weights")
    a = ap.parse_args(argv)
    model = ToyModel.load(a.model_dir, a.delta)
    items = tt.read_jsonl(a.items) if a.items else tt.dev_items()
    res = evaluate(model, items)
    print("TOOL OK")
    print(tt.format_scores(res["per_skill"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
