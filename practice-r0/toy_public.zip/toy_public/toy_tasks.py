"""toy_tasks.py: the four toy skills, their item generators, a greedy decode helper and the exact scorer.

PUBLIC FILE. It ships in toy_public.zip (BATTLE_LADDER design §2.3, §2.4 step 6, §2.5). Standard library only.

Skills and formats (tokens are separated by one space; every answer ends with <eos>):

  COPY  <copy> a c b e <sep>      ->  a c b e <eos>       letters a-h, length 2-7
  ADD   <add> 4 7 + 3 8 <sep>     ->  5 8 <eos>           two 2-digit numbers (10-99); the sum (here 85)
                                                          is written lowest digit first
  SORT  <sort> 4 1 3 9 <sep>      ->  1 3 4 9 <eos>       digits 0-9, length 2-6, repeats allowed
  STOP  <rep> 3 b <sep>           ->  b b b <eos>         n 1-9, the token is a letter a-h

Determinism: items come from a seed string through a fixed SplitMix64 generator and sha256 sub-seeds, so the same
seed gives byte-identical items on every Python version and platform (no use of the `random` module).
Dev items use the PUBLIC seed DEV_SEED. Sealed seeds are drawn elsewhere and are never in this file.

Scoring (§2.5): exact match per item. The model's greedy output, capped at CAP tokens, is cut after its first
<eos>; the item is right only if that token list equals the gold answer (which ends with <eos>). An output with
no <eos> inside the cap is wrong.

CLI:
  python toy_tasks.py dev --out dev_items.jsonl          # writes the public dev set (2,000 items per skill)
  python toy_tasks.py show --seed <text> --n 3            # prints a few items of each skill
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys

FORMAT_VERSION = "toy-tasks-v1"
DEV_SEED = "battle-ladder-toy-dev-v1"   # public; dev items come only from this seed
N_PER_SKILL = 2000                     # §2.5: 2,000 items per skill in every set
CAP = 32                               # §2.5: greedy output cap, in tokens

SKILLS = ("COPY", "ADD", "SORT", "STOP")
LETTERS = tuple("abcdefgh")
DIGITS = tuple("0123456789")
TASK_TOKEN = {"COPY": "<copy>", "ADD": "<add>", "SORT": "<sort>", "STOP": "<rep>"}

# Fixed vocabulary of 32 word-level tokens (ids are positions). tokenizer.json is built from this list.
VOCAB = (
    ["<pad>", "<unk>", "<bos>", "<eos>", "<sep>", "<copy>", "<add>", "<sort>", "<rep>", "+"]
    + list(DIGITS) + list(LETTERS)
    + ["<unused0>", "<unused1>", "<unused2>", "<unused3>"]
)
assert len(VOCAB) == 32 and len(set(VOCAB)) == 32
TOK2ID = {t: i for i, t in enumerate(VOCAB)}
PAD_ID, UNK_ID, BOS_ID, EOS_ID, SEP_ID = (TOK2ID[t] for t in ("<pad>", "<unk>", "<bos>", "<eos>", "<sep>"))
SPECIAL = ("<pad>", "<unk>", "<bos>", "<eos>", "<sep>", "<copy>", "<add>", "<sort>", "<rep>",
           "<unused0>", "<unused1>", "<unused2>", "<unused3>")

# Ranges (§2.3)
COPY_LEN = (2, 7)
SORT_LEN = (2, 6)
ADD_RANGE = (10, 99)
STOP_N = (1, 9)

_MASK = (1 << 64) - 1


# --------------------------------------------------------------------------------------------- random numbers
class Rng:
    """SplitMix64. Small, fixed and identical everywhere."""

    def __init__(self, seed_int: int):
        self.s = seed_int & _MASK

    def next64(self) -> int:
        self.s = (self.s + 0x9E3779B97F4A7C15) & _MASK
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & _MASK
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & _MASK
        return z ^ (z >> 31)

    def below(self, n: int) -> int:
        """Uniform integer in [0, n), no modulo bias."""
        if n <= 0:
            raise ValueError("n must be positive")
        limit = (1 << 64) - ((1 << 64) % n)
        while True:
            x = self.next64()
            if x < limit:
                return x % n

    def between(self, lo: int, hi: int) -> int:
        """Uniform integer in [lo, hi] (both ends included)."""
        return lo + self.below(hi - lo + 1)

    def choice(self, seq):
        return seq[self.below(len(seq))]

    def shuffle(self, lst: list) -> None:
        for i in range(len(lst) - 1, 0, -1):
            j = self.below(i + 1)
            lst[i], lst[j] = lst[j], lst[i]


def seed_text(seed) -> str:
    """A seed may be text or bytes (a drawn seed file); bytes are used as lowercase hex."""
    if isinstance(seed, (bytes, bytearray)):
        return bytes(seed).hex()
    if isinstance(seed, str):
        return seed
    raise TypeError("seed must be str or bytes")


def derive(seed, *labels) -> int:
    """A 64-bit sub-seed from a seed and labels (sha256; labels joined with '|')."""
    msg = "|".join([FORMAT_VERSION, seed_text(seed)] + [str(x) for x in labels]).encode("utf-8")
    return int.from_bytes(hashlib.sha256(msg).digest()[:8], "big")


def rng_for(seed, *labels) -> Rng:
    return Rng(derive(seed, *labels))


# --------------------------------------------------------------------------------------------- one item
def gold_answer(skill: str, args: list[str]) -> list[str]:
    """Gold answer tokens (ending with <eos>) for the prompt body `args` (tokens between the task token and <sep>)."""
    if skill == "COPY":
        return list(args) + ["<eos>"]
    if skill == "ADD":
        if len(args) != 5 or args[2] != "+":
            raise ValueError("bad ADD args")
        a = int(args[0] + args[1])
        b = int(args[3] + args[4])
        return list(reversed(str(a + b))) + ["<eos>"]
    if skill == "SORT":
        return sorted(args, key=int) + ["<eos>"]
    if skill == "STOP":
        n, tok = int(args[0]), args[1]
        return [tok] * n + ["<eos>"]
    raise ValueError(f"unknown skill {skill!r}")


def sample_args(skill: str, rng: Rng) -> list[str]:
    """Prompt body tokens for one item of `skill`."""
    if skill == "COPY":
        n = rng.between(*COPY_LEN)
        return [rng.choice(LETTERS) for _ in range(n)]
    if skill == "ADD":
        a = rng.between(*ADD_RANGE)
        b = rng.between(*ADD_RANGE)
        return [str(a)[0], str(a)[1], "+", str(b)[0], str(b)[1]]
    if skill == "SORT":
        n = rng.between(*SORT_LEN)
        return [rng.choice(DIGITS) for _ in range(n)]
    if skill == "STOP":
        return [str(rng.between(*STOP_N)), rng.choice(LETTERS)]
    raise ValueError(f"unknown skill {skill!r}")


def make_item(skill: str, args: list[str], item_id: str = "") -> dict:
    prompt = [TASK_TOKEN[skill]] + list(args) + ["<sep>"]
    return {"id": item_id, "skill": skill, "prompt": " ".join(prompt), "answer": " ".join(gold_answer(skill, args))}


def parse_prompt(prompt: str) -> tuple[str, list[str]]:
    """Inverse of make_item: (skill, args) from a prompt string."""
    toks = prompt.split()
    if len(toks) < 2 or toks[-1] != "<sep>":
        raise ValueError("prompt must end with <sep>")
    inv = {v: k for k, v in TASK_TOKEN.items()}
    if toks[0] not in inv:
        raise ValueError("unknown task token")
    return inv[toks[0]], toks[1:-1]


# --------------------------------------------------------------------------------------------- sets
def make_items(skill: str, n: int, seed, label: str = "set") -> list[dict]:
    """n items of one skill. Deterministic in (seed, label, skill)."""
    if skill not in SKILLS:
        raise ValueError(f"unknown skill {skill!r}")
    rng = rng_for(seed, label, skill)
    return [make_item(skill, sample_args(skill, rng), f"{skill}-{i:05d}") for i in range(n)]


def make_set(seed, n_per_skill: int = N_PER_SKILL, label: str = "set") -> list[dict]:
    """n_per_skill items of each skill, in SKILLS order."""
    out = []
    for skill in SKILLS:
        out.extend(make_items(skill, n_per_skill, seed, label))
    return out


def dev_items(n_per_skill: int = N_PER_SKILL) -> list[dict]:
    """The public dev set."""
    return make_set(DEV_SEED, n_per_skill, label="dev")


def items_to_jsonl(items: list[dict]) -> bytes:
    lines = [json.dumps({k: it[k] for k in ("id", "skill", "prompt", "answer")}, sort_keys=True,
                        separators=(",", ":")) for it in items]
    return ("\n".join(lines) + "\n").encode("utf-8")


def read_jsonl(path: str) -> list[dict]:
    with open(path, "r", encoding="utf-8") as fh:
        return [json.loads(line) for line in fh if line.strip()]


# --------------------------------------------------------------------------------------------- tokens
def encode(text: str) -> list[int]:
    out = []
    for t in text.split():
        if t not in TOK2ID:
            raise ValueError(f"token not in vocab: {t!r}")
        out.append(TOK2ID[t])
    return out


def decode(ids) -> list[str]:
    return [VOCAB[int(i)] for i in ids]


def tokenizer_json() -> dict:
    """A word-level tokenizer.json (Hugging Face `tokenizers` format) for VOCAB."""
    added = [{"id": TOK2ID[t], "content": t, "single_word": False, "lstrip": False, "rstrip": False,
              "normalized": False, "special": True} for t in SPECIAL]
    return {
        "version": "1.0",
        "truncation": None,
        "padding": None,
        "added_tokens": added,
        "normalizer": None,
        "pre_tokenizer": {"type": "WhitespaceSplit"},
        "post_processor": None,
        "decoder": None,
        "model": {"type": "WordLevel", "vocab": {t: i for i, t in enumerate(VOCAB)}, "unk_token": "<unk>"},
    }


def tokenizer_json_bytes() -> bytes:
    return (json.dumps(tokenizer_json(), indent=1, sort_keys=False, ensure_ascii=True) + "\n").encode("utf-8")


# --------------------------------------------------------------------------------------------- greedy + score
def argmax_first(row) -> int:
    """Index of the first maximum (the same tie rule as numpy.argmax and torch.argmax)."""
    best_i, best_v = 0, row[0]
    for i in range(1, len(row)):
        if row[i] > best_v:
            best_i, best_v = i, row[i]
    return best_i


def cut_at_eos(tokens: list[str]) -> list[str]:
    if "<eos>" in tokens:
        return tokens[: tokens.index("<eos>") + 1]
    return list(tokens)


def greedy_generate(next_logits, prompt_ids: list[int], cap: int = CAP) -> list[int]:
    """Plain greedy loop for any backend: next_logits(ids) -> logits (sequence) for the next token.

    Stops after <eos> or after `cap` generated tokens. Slow (no cache); toy_np.py has a batched cached runner.
    """
    ids = list(prompt_ids)
    out = []
    for _ in range(cap):
        nxt = argmax_first(list(next_logits(ids)))
        out.append(nxt)
        ids.append(nxt)
        if nxt == EOS_ID:
            break
    return out


def score(items: list[dict], outputs: list[list[str]]) -> dict:
    """Exact match per item and accuracy per skill.

    outputs[i] is the generated token list (strings) for items[i], as produced by greedy decoding with the cap.
    Returns {"per_item": [bool...], "per_skill": {skill: accuracy}, "counts": {skill: [right, total]}}.
    """
    if len(items) != len(outputs):
        raise ValueError("items and outputs differ in length")
    per_item = []
    counts = {s: [0, 0] for s in SKILLS}
    for it, out in zip(items, outputs):
        gold = it["answer"].split()
        got = cut_at_eos(list(out)[:CAP])
        ok = got == gold
        per_item.append(ok)
        counts[it["skill"]][1] += 1
        counts[it["skill"]][0] += int(ok)
    per_skill = {s: (c[0] / c[1] if c[1] else float("nan")) for s, c in counts.items()}
    return {"per_item": per_item, "per_skill": per_skill, "counts": counts}


def format_scores(per_skill: dict) -> str:
    return " ".join(f"{s}={100.0 * per_skill[s]:.2f}" for s in SKILLS if s in per_skill)


# --------------------------------------------------------------------------------------------- CLI
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(allow_abbrev=False, description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("dev", allow_abbrev=False, help="write the public dev items as JSONL")
    d.add_argument("--out", required=True)
    s = sub.add_parser("show", allow_abbrev=False, help="print a few items of each skill for a seed")
    s.add_argument("--seed", default=DEV_SEED)
    s.add_argument("--n", type=int, default=3)
    a = ap.parse_args(argv)
    if a.cmd == "dev":
        data = items_to_jsonl(dev_items())
        with open(a.out, "wb") as fh:
            fh.write(data)
        print(f"wrote {a.out} items={len(SKILLS) * N_PER_SKILL} sha256={hashlib.sha256(data).hexdigest()}")
        return 0
    if a.cmd == "show":
        for skill in SKILLS:
            for it in make_items(skill, a.n, a.seed, "show"):
                print(f"{it['prompt']}  ->  {it['answer']}")
        return 0
    return 3


if __name__ == "__main__":
    sys.exit(main())
